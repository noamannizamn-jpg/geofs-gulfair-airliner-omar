Gulf Airliner 800 (Omar Edition)
=================================

Features:
- Gulf Air - Omar livery (custom text on fuselage)
- Afterburner (press B) = +50% thrust
- Flaps (press F) = stages 0°, 10°, 20°, 30°
- Spoilers (press /) = deploy to add drag
- Simple cockpit HUD

How to install:
1. Upload `aircraft.xml`, `airliner.dae`, and `texture.png` to a public host (GitHub, GitLab, Dropbox direct link, etc.)
2. Copy the public URL of `aircraft.xml`
3. In GeoFS → Settings → Community Contributed Aircraft → paste the URL
4. Select "Gulf Airliner 800 (Omar Edition)"

Enjoy your custom jet!
